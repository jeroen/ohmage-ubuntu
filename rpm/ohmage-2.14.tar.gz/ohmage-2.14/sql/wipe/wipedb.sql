FLUSH PRIVILEGES;
DROP DATABASE ohmage;
DROP USER 'ohmage'@'localhost';
