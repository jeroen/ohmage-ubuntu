FLUSH PRIVILEGES;
DROP DATABASE IF EXISTS ohmage;
GRANT USAGE ON *.* TO 'ohmage'@'localhost';
DROP USER 'ohmage'@'localhost';

