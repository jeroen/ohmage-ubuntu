-- Inserts the additional, CHIPTS-specific survey response privacy states.
INSERT INTO survey_response_privacy_state(privacy_state) VALUES 
    ('invisible');