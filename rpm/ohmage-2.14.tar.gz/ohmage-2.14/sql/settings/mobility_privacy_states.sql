-- Inserts the default Mobility privacy states into the lookup table in the database.
INSERT INTO mobility_privacy_state(privacy_state) VALUES 
    ('private');