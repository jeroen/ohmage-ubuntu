-- Inserts the default survey response privacy states into the lookup table in the database.
INSERT INTO survey_response_privacy_state(privacy_state) VALUES 
    ('shared'), 
    ('private');