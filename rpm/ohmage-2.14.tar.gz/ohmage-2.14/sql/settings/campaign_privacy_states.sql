-- Inserts the default campaign privacy states into the lookup table in the database.
INSERT INTO campaign_privacy_state(privacy_state) VALUES 
    ('shared'), 
    ('private');