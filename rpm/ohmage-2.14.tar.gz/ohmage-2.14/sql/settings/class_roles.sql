-- Insert the default roles for a class.
INSERT INTO user_class_role(role) VALUES 
    ('privileged'), 
    ('restricted');