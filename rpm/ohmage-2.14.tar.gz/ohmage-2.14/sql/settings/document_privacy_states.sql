-- Inserts the default document privacy states into the lookup table in the database.
INSERT INTO document_privacy_state(privacy_state) VALUES 
    ('private'), 
    ('shared');