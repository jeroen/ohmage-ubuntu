-- Insert the default roles for a document.
INSERT INTO document_role(role) VALUES 
    ('reader'), 
    ('writer'), 
    ('owner');
