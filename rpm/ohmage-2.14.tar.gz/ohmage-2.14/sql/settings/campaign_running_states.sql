-- Inserts the default campaign running states into the lookup table in the database.
INSERT INTO campaign_running_state(running_state) VALUES
    ('running'), 
    ('stopped');