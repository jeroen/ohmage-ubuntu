-- Creates the default, public class.
INSERT INTO class(urn, name, description)
    VALUES ('urn:class:public', 'Public Class', 'This is the public class for all self-registered users.');