# TODO: Add comment
# 
# Author: jeroen
###############################################################################


oh.login('ohmage.admin','ohmage.passwd','https://cens.opencpu.org/app');
