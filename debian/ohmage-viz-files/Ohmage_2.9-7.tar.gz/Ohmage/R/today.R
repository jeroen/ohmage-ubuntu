today <- function(){
	return(as.character(as.Date(Sys.time())));
}
