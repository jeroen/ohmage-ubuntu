#load the package
library(Ohmage)

#\dontrun{
	
#authentication works like a cookie.
#oh.login("ohmage.admin", "ohmage.passwd", "https://example.com/app")

#list campaigns you are in
#oh.campaign.read()

#read some data
#oh.survey_response.read("urn:ohmage:campaign:mycampaign");

#}
