# TODO: Add comment
# 
# Author: jeroen
###############################################################################

.onLoad <- function(lib, pkg){
	
	options(TOKEN = NULL)
	options(SERVERURL = NULL)
	options(CLIENTNAME = "R-Ohmage")
	options(CURLCOUNT = 0);

}