# TODO: Add comment
# 
# Author: jeroen
###############################################################################


oh.login("ohmage.admin", "ohmage.passwd", "https://omh.opencpu.org")
