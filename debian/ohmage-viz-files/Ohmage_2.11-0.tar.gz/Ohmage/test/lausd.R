#Jefferson snack p5 and p6, la high ad and snack

library(Ohmage);
library(maps);
oh.login("mobilize.coach1", "Marsupial.12", "https://lausd.mobilizingcs.org/app");
oh.campaign.read();
mycolumns = c("urn:ohmage:prompt:response", "urn:ohmage:context:location:longitude", "urn:ohmage:context:location:latitude" )
mydata <- oh.survey_response.read("urn:campaign:lausd:Jefferson:SP2012:ECS_P5:Snack", column_list=mycolumns);
