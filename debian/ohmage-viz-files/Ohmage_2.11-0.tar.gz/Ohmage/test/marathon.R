#Make sure these packages are installed
library(Ohmage);
library(dpu.mobility);
library(maps);
library(ggplot2);

oh.login("bootcamp2", "Bootcamp.2", "https://dev.andwellness.org/app");
mydata <- oh.mobility.read(date="2012-03-18", username="ohmage.estrin", with_sensor_data="true");

#check if we have a full day of data:
names(mydata);
nrow(mydata);

#delete missing data
missings <- which(is.na(mydata$la) | is.na(mydata$lo));
if(length(missings) > 0){
	mydata <- mydata[-(missings),];
}

#remaining rows:
nrow(mydata);

#explore data
map("county", c("california,los angeles"))
map.axes()
points(mydata$lo, mydata$la,cex=.5);

#use lines instead
map("county", c("california,los angeles"))
map.axes()
lines(mydata$lo, mydata$la, type="l", col="red");

#not a lot happening before 5AM:
geodistance(mydata$lo[1:300], mydata$la[1:300])

#calculate total distance traveled:
geodistance(mydata$lo, mydata$la)

#distance per minute:
mydata$distance <- c(0,geodistance(mydata$lo, mydata$la, total=FALSE));

#distance of the day:
qplot(t, distance, data=mydata)
qplot(t, speed, data=mydata)

#subset the maraton:
starttime <- as.POSIXct("2012-03-18 07:30");
endtime   <- as.POSIXct("2012-03-18 12:00");
marathon <- mydata[mydata$t > starttime & mydata$t < endtime,]

#map of the maraton data
map("county", c("california,los angeles"))
map.axes()
lines(marathon$lo, marathon$la, type="l", col="red");

#maraton distance:
qplot(t, distance, data=marathon);
qplot(t, speed, data=marathon);

#correlation
qplot(speed, distance, data=mydata) + geom_smooth()
qplot(speed, distance, data=marathon) + geom_smooth()


