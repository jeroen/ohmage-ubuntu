if (Sys.info()["user"] == "hadley")  {
 library(devtools)
 # check("reshape2", document = FALSE)
 check_cran("lubridate")
 check_cran("ggplot2")
 check_cran("reshape")
 check_cran("stringr")
 check_cran("nullabor")
 check_cran("stringr")
 check_cran("productplots")
 check_cran("reshape2")

}