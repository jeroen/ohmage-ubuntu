library(testthat)
library(scales)

test_package("scales")