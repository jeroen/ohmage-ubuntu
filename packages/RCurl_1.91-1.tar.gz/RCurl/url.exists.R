library(RCurl)
url.exists("www.google.com")
url.exists("www.google.css")
url.exists("www.omegahat.org")

