#include <Rdefines.h>

void
foo()
{
 void *p;
 R_RemoveExtPtrWeakRef_direct(p);
}

