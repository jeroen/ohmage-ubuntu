library(testthat)
library(reshape2)

test_package("reshape2")